# Pasaporte Wexpand · Comunidad en WhatsApp

Landing interactiva (HTML estático) para invitar a la comunidad de WhatsApp de Wexpand.

- `index.html` — la página completa (pasaporte 3D, visas, carrusel de fotos, pase de abordar)
- `w/` — Wexpandcitos (WebP)
- `fotos/` — fotos de cultura
- `og.jpg` — imagen para compartir en WhatsApp/redes

No requiere build: Vercel la publica tal cual.
Para cambiar el enlace del grupo, busca `chat.whatsapp.com` en `index.html`.
